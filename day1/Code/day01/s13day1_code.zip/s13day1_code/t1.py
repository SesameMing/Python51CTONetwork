# -*- coding:utf-8 -*-
# Author:Alex Li

name = input("input your name:")
age = int(input("input your age:") ) #convert str to int
job = input("input your job:")

msg = '''
Infomation of user %s:
---------------
Name:   %s
Age :   %f d s
Job :   %s
-------End-----
''' % (name,name,age,job )
print(msg)





'''
#..最多不能超过80个字符每行...
## his code to mutiply .....xhis code to mutiply .....
xhis code to mutiply .....xhis code to mutiply .....
xhis code to mutiply .....xhis code to mutiply .....
xhis code to mutiply .....xhis code to mutiply ....
.xhis code to mutiply .....x
res = map(lambda x:x**x, range(10)) #this code to mutiply .....x
'''

