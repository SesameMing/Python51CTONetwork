#!/usr/bin/env python
# -*- coding:utf-8 -*-
'''
name = "Alex"
name2 = name
print(name,name2)
name = 'LongmingWang'
print(name,name2)
'''


name = "Alex Li"
age = 21
province = 'shandong'
company = 'oldboy'
son_of_twins_brother_age = 2
NameOfTwinsGf = "FengJie"
'''
#name-of-twins-gf = "sdgsdf"
#name8
#name of twins
#print(v1,v2,v3,v4 )
